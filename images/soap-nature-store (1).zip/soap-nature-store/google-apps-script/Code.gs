const SHEET_ORDERS = 'Orders';
const SHEET_ITEMS = 'OrderItems';
const SHEET_PRODUCTS = 'Products';

function doGet(e) {
  const action = e && e.parameter && e.parameter.action;
  if (action === 'listOrders') return json_({ success: true, orders: listOrders_() });
  return json_({ success: true, message: 'Soap Nature API is running' });
}

function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents || '{}');
    if (body.action === 'createOrder') return json_(createOrder_(body.order));
    if (body.action === 'updateStatus') return json_(updateStatus_(body.orderId, body.status));
    return json_({ success: false, message: 'Unknown action' });
  } catch (err) {
    return json_({ success: false, message: String(err.message || err) });
  }
}

function setupSheets() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  ensureSheet_(ss, SHEET_ORDERS, ['Order ID','Created At','Customer Name','Phone','Address','District','Province','Postcode','Total','Status']);
  ensureSheet_(ss, SHEET_ITEMS, ['Order ID','SKU','Product Name','Price','Quantity','Line Total']);
  ensureSheet_(ss, SHEET_PRODUCTS, ['SKU','Product Name','Price','Active']);
  const products = ss.getSheetByName(SHEET_PRODUCTS);
  if (products.getLastRow() === 1) {
    products.getRange(2,1,2,4).setValues([
      ['SOAP-001','สบู่ว่านหางจระเข้',59,true],
      ['SOAP-002','สบู่ขมิ้นชัน',69,true]
    ]);
  }
}
function ensureSheet_(ss, name, headers) {
  let sh = ss.getSheetByName(name);
  if (!sh) sh = ss.insertSheet(name);
  if (sh.getLastRow() === 0) sh.appendRow(headers);
  sh.setFrozenRows(1);
  sh.getRange(1,1,1,headers.length).setFontWeight('bold').setBackground('#e8eee3');
}
function createOrder_(o) {
  if (!o || !o.orderId || !o.name || !o.phone || !o.address || !o.province || !o.postcode || !o.items || !o.items.length) throw new Error('ข้อมูลคำสั่งซื้อไม่ครบถ้วน');
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const orders = ss.getSheetByName(SHEET_ORDERS);
  const items = ss.getSheetByName(SHEET_ITEMS);
  if (!orders || !items) throw new Error('กรุณารัน setupSheets() ก่อน');
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    if (orders.createTextFinder(o.orderId).matchEntireCell(true).findNext()) throw new Error('เลขคำสั่งซื้อนี้มีอยู่แล้ว');
    orders.appendRow([safe_(o.orderId), new Date(o.createdAt || new Date()), safe_(o.name), safe_(o.phone), safe_(o.address), safe_(o.district), safe_(o.province), safe_(o.postcode), Number(o.total)||0, 'รอหยิบสินค้า']);
    const rows = o.items.map(i => [safe_(o.orderId), safe_(i.sku), safe_(i.name), Number(i.price)||0, Number(i.qty)||0, (Number(i.price)||0)*(Number(i.qty)||0)]);
    if (rows.length) items.getRange(items.getLastRow()+1,1,rows.length,6).setValues(rows);
  } finally { lock.releaseLock(); }
  return { success: true, orderId: o.orderId };
}
function listOrders_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sh = ss.getSheetByName(SHEET_ORDERS), itemSh = ss.getSheetByName(SHEET_ITEMS);
  if (!sh || !itemSh || sh.getLastRow() < 2) return [];
  const rows = sh.getRange(2,1,sh.getLastRow()-1,10).getValues();
  const itemRows = itemSh.getLastRow() < 2 ? [] : itemSh.getRange(2,1,itemSh.getLastRow()-1,6).getValues();
  return rows.reverse().map(r => ({
    orderId:String(r[0]), createdAt:r[1] instanceof Date ? r[1].toISOString() : String(r[1]),
    name:String(r[2]), phone:String(r[3]), address:String(r[4]), district:String(r[5]),
    province:String(r[6]), postcode:String(r[7]), total:Number(r[8]), status:String(r[9]),
    items:itemRows.filter(x=>String(x[0])===String(r[0])).map(x=>({sku:String(x[1]),name:String(x[2]),price:Number(x[3]),qty:Number(x[4])}))
  }));
}
function updateStatus_(orderId, status) {
  const allowed = ['รอหยิบสินค้า','กำลังหยิบสินค้า','กำลังแพ็ก','แพ็กเรียบร้อย','จัดส่งแล้ว'];
  if (!allowed.includes(status)) throw new Error('สถานะไม่ถูกต้อง');
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_ORDERS);
  if (!sh) throw new Error('ไม่พบชีต Orders');
  const finder = sh.getRange(2,1,Math.max(sh.getLastRow()-1,1),1).createTextFinder(String(orderId)).matchEntireCell(true);
  const cell = finder.findNext();
  if (!cell) throw new Error('ไม่พบคำสั่งซื้อ');
  sh.getRange(cell.getRow(),10).setValue(status);
  return { success:true };
}
function safe_(value) { return String(value == null ? '' : value).replace(/^[=+\-@]/, "'$&"); }
function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}