import React, { useEffect, useMemo, useState } from 'react'
import { Leaf, ShoppingBag, PackageCheck, ClipboardList, Printer, Plus, Minus, Search, Menu, X, CheckCircle2, Truck } from 'lucide-react'

const PRODUCTS = [
  { sku:'SOAP-001', name:'สบู่ว่านหางจระเข้', subtitle:'Aloe Vera Soap', price:59, desc:'สบู่ทำความสะอาดผิว สูตรว่านหางจระเข้ เหมาะสำหรับการดูแลผิวประจำวัน', image:'/images/aloe-soap.jpg', tag:'ขายดี' },
  { sku:'SOAP-002', name:'สบู่ขมิ้นชัน', subtitle:'Turmeric Herbal Soap', price:69, desc:'สบู่สมุนไพรขมิ้นชัน กลิ่นหอมอ่อน ๆ สำหรับการทำความสะอาดผิว', image:'/images/turmeric-soap.jpg', tag:'สมุนไพร' }
]
const API = import.meta.env.VITE_SHEETS_WEB_APP_URL
const money = n => new Intl.NumberFormat('th-TH').format(n) + ' บาท'
const emptyAddress = {name:'', phone:'', address:'', district:'', province:'', postcode:''}

export default function App() {
  const [cart,setCart] = useState({})
  const [customer,setCustomer] = useState(emptyAddress)
  const [notice,setNotice] = useState('')
  const [tab,setTab] = useState('shop')
  const [orders,setOrders] = useState([])
  const [loading,setLoading] = useState(false)
  const [search,setSearch] = useState('')
  const [mobileMenu,setMobileMenu] = useState(false)
  const [packingOrder,setPackingOrder] = useState(null)
  const [checked,setChecked] = useState({})
  const [manualOrders,setManualOrders] = useState([])

  const cartItems = useMemo(() => PRODUCTS.filter(p => cart[p.sku] > 0).map(p => ({...p,qty:cart[p.sku]})),[cart])
  const totalQty = cartItems.reduce((s,p)=>s+p.qty,0)
  const total = cartItems.reduce((s,p)=>s+p.price*p.qty,0)
  const updateQty = (sku,delta) => setCart(old => ({...old,[sku]:Math.max(0,(old[sku]||0)+delta)}))
  const changeCustomer = e => setCustomer(old=>({...old,[e.target.name]:e.target.value}))

  async function submitOrder(e) {
    e.preventDefault()
    if (!cartItems.length) return setNotice('กรุณาเลือกสินค้าก่อนสั่งซื้อ')
    if (!customer.name || !customer.phone || !customer.address || !customer.province || !customer.postcode) return setNotice('กรุณากรอกข้อมูลจัดส่งให้ครบถ้วน')
    if (!/^[0-9]{9,10}$/.test(customer.phone.replace(/-/g,''))) return setNotice('กรุณาตรวจสอบเบอร์โทรศัพท์')
    if (!/^[0-9]{5}$/.test(customer.postcode)) return setNotice('รหัสไปรษณีย์ต้องมี 5 หลัก')
    const order = {orderId:'SN'+Date.now(),createdAt:new Date().toISOString(),...customer,items:cartItems.map(({sku,name,price,qty})=>({sku,name,price,qty})),total,status:'รอหยิบสินค้า'}
    setLoading(true); setNotice('')
    try {
      if (API) {
        const response = await fetch(API,{method:'POST',headers:{'Content-Type':'text/plain;charset=utf-8'},body:JSON.stringify({action:'createOrder',order})})
        const result = await response.json()
        if (!result.success) throw new Error(result.message || 'บันทึกข้อมูลไม่สำเร็จ')
      } else {
        setManualOrders(old=>[order,...old])
      }
      setNotice(`สั่งซื้อสำเร็จ เลขที่คำสั่งซื้อ ${order.orderId}`)
      setCart({}); setCustomer(emptyAddress)
    } catch(err) { setNotice('ไม่สามารถบันทึกคำสั่งซื้อได้: '+err.message) }
    finally { setLoading(false) }
  }

  async function loadOrders() {
    setLoading(true)
    try {
      if (API) {
        const r = await fetch(`${API}?action=listOrders`)
        const data = await r.json()
        if (!data.success) throw new Error(data.message || 'โหลดรายการไม่สำเร็จ')
        setOrders(data.orders || [])
      } else setOrders(manualOrders)
    } catch(e) { setNotice('โหลดคำสั่งซื้อไม่สำเร็จ: '+e.message) }
    finally { setLoading(false) }
  }
  useEffect(()=>{ if(tab==='fulfillment') loadOrders() },[tab])
  const setStatus = async (order,status) => {
    try {
      if (API) {
        const r=await fetch(API,{method:'POST',headers:{'Content-Type':'text/plain;charset=utf-8'},body:JSON.stringify({action:'updateStatus',orderId:order.orderId,status})})
        const d=await r.json(); if(!d.success) throw new Error(d.message)
      } else setManualOrders(old=>old.map(o=>o.orderId===order.orderId?{...o,status}:o))
      setOrders(old=>old.map(o=>o.orderId===order.orderId?{...o,status}:o))
      setNotice(`อัปเดตสถานะ ${order.orderId} เป็น ${status} แล้ว`)
    } catch(e) { setNotice('อัปเดตสถานะไม่สำเร็จ: '+e.message) }
  }
  const visibleOrders = orders.filter(o => (o.orderId||'').toLowerCase().includes(search.toLowerCase()) || (o.name||'').toLowerCase().includes(search.toLowerCase()))
  const openLabel = order => {
    const w=window.open('','_blank','width=800,height=900')
    if(!w) return setNotice('เบราว์เซอร์บล็อกหน้าต่างพิมพ์ กรุณาอนุญาต pop-up')
    const rows=(order.items||[]).map(i=>`<tr><td>${i.sku}</td><td>${i.name}</td><td>${i.qty}</td></tr>`).join('')
    w.document.write(`<!doctype html><html lang="th"><head><meta charset="utf-8"><title>ใบจ่าหน้าพัสดุ ${order.orderId}</title><style>body{font-family:Arial,sans-serif;padding:24px;color:#222}.label{border:2px solid #222;padding:22px;max-width:650px;margin:auto}h2{margin:0 0 12px}table{width:100%;border-collapse:collapse;margin-top:16px}td,th{border:1px solid #777;padding:8px;text-align:left}.small{font-size:12px;color:#555}.big{font-size:20px;font-weight:bold}@media print{button{display:none}}</style></head><body><div class="label"><h2>SOAP NATURE</h2><div class="small">ใบจ่าหน้าพัสดุ / SHIPPING LABEL</div><hr><p><b>ผู้รับ</b></p><div class="big">${escapeHtml(order.name||'')}</div><p>${escapeHtml(order.address||'')} ${escapeHtml(order.district||'')} ${escapeHtml(order.province||'')} ${escapeHtml(order.postcode||'')}</p><p>โทร. ${escapeHtml(order.phone||'')}</p><hr><p>เลขที่คำสั่งซื้อ: <b>${escapeHtml(order.orderId||'')}</b></p><table><thead><tr><th>SKU</th><th>สินค้า</th><th>จำนวน</th></tr></thead><tbody>${rows}</tbody></table><p><b>ยอดรวม: ${money(Number(order.total)||0)}</b></p><p class="small">กรุณาตรวจสอบชื่อ ที่อยู่ เบอร์โทรศัพท์ และรายการสินค้าก่อนจัดส่ง</p><button onclick="window.print()">พิมพ์ใบจ่าหน้าพัสดุ</button></div></body></html>`)
    w.document.close()
  }
  function escapeHtml(v){return String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}

  return <div className="app">
    <header className="header"><a className="brand" href="#" onClick={()=>setTab('shop')}><span className="brand-icon"><Leaf size={22}/></span><span>SOAP <b>NATURE</b><small>ธรรมชาติ เพื่อผิวของคุณ</small></span></a>
      <button className="menu-toggle" onClick={()=>setMobileMenu(!mobileMenu)} aria-label="เมนู">{mobileMenu?<X/>:<Menu/>}</button>
      <nav className={mobileMenu?'nav open':'nav'}><button className={tab==='shop'?'active':''} onClick={()=>{setTab('shop');setMobileMenu(false)}}>หน้าร้าน</button><button className={tab==='fulfillment'?'active':''} onClick={()=>{setTab('fulfillment');setMobileMenu(false)}}><PackageCheck size={16}/> จัดการออเดอร์</button><a href="#products">สินค้า</a></nav>
      <button className="cart-pill" onClick={()=>setTab('shop')}><ShoppingBag size={17}/> ตะกร้า <b>{totalQty}</b></button>
    </header>

    {notice && <div className="notice"><CheckCircle2 size={17}/>{notice}<button onClick={()=>setNotice('')}>ปิด</button></div>}

    {tab==='shop' ? <>
      <main>
        <section className="hero"><div className="hero-copy"><span className="eyebrow"><Leaf size={15}/> NATURAL HERBAL SOAP</span><h1>ดูแลผิวอย่างอ่อนโยน<br/><em>ด้วยพลังจากธรรมชาติ</em></h1><p>สบู่สมุนไพรที่คัดสรรส่วนผสมอย่างใส่ใจ เพื่อช่วงเวลาดี ๆ ในการดูแลตัวเองทุกวัน</p><a className="primary-btn" href="#products">เลือกซื้อสินค้า <span>→</span></a><div className="hero-note"><span>✦</span> เรียบง่าย อ่อนโยน ใส่ใจทุกก้อน</div></div><div className="hero-art"><div className="hero-circle"></div><img src="/images/banner.jpg" alt="สบู่ธรรมชาติ Soap Nature" onError={e=>{e.currentTarget.style.display='none'}}/><div className="hero-stamp">PURE<br/>NATURE</div></div></section>
        <section className="benefits"><div><span>✿</span><b>ส่วนผสมจากธรรมชาติ</b><small>คัดสรรวัตถุดิบอย่างใส่ใจ</small></div><div><span>♡</span><b>ดูแลผิวทุกวัน</b><small>เหมาะกับกิจวัตรประจำวัน</small></div><div><span>♧</span><b>แพ็กอย่างตั้งใจ</b><small>ตรวจสอบสินค้าก่อนจัดส่ง</small></div></section>
        <section id="products" className="products-section"><div className="section-heading"><div><span className="eyebrow">OUR PRODUCTS</span><h2>เลือกสบู่ที่ใช่สำหรับคุณ</h2><p>เรียบง่ายจากธรรมชาติ ในทุกขั้นตอนการดูแลผิว</p></div><span className="product-count">2 PRODUCTS</span></div><div className="product-grid">{PRODUCTS.map(p=><article className="product-card" key={p.sku}><div className="product-image"><span className="tag">{p.tag}</span><img src={p.image} alt={p.name} onError={e=>{e.currentTarget.src='/images/soap-placeholder.svg'}}/></div><div className="product-info"><span className="sku">{p.sku}</span><h3>{p.name}</h3><small>{p.subtitle}</small><p>{p.desc}</p><div className="product-bottom"><b>{money(p.price)}</b><button onClick={()=>updateQty(p.sku,1)}><Plus size={16}/> เพิ่มลงตะกร้า</button></div></div></article>)}</div></section>
        <section className="order-section"><div className="order-intro"><span className="eyebrow">ORDER FORM</span><h2>สั่งซื้อสินค้า</h2><p>เลือกสินค้าและกรอกข้อมูลจัดส่งให้ครบถ้วน ระบบจะบันทึกคำสั่งซื้อไปยัง Google Sheets</p><div className="secure-note"><ClipboardList size={19}/> ข้อมูลคำสั่งซื้อจะถูกส่งไปยังระบบจัดการหลังบ้าน</div></div><div className="order-panel"><h3><ShoppingBag size={19}/> รายการในตะกร้า</h3>{cartItems.length===0?<p className="empty">ยังไม่มีสินค้าในตะกร้า เลือกสินค้าด้านบนเพื่อเริ่มสั่งซื้อ</p>:cartItems.map(p=><div className="cart-row" key={p.sku}><div><b>{p.name}</b><small>{p.sku} · {money(p.price)}</small></div><div className="qty"><button onClick={()=>updateQty(p.sku,-1)}><Minus size={13}/></button><b>{p.qty}</b><button onClick={()=>updateQty(p.sku,1)}><Plus size={13}/></button></div><strong>{money(p.price*p.qty)}</strong></div>)}<div className="total-row"><span>ยอดรวมทั้งสิ้น</span><b>{money(total)}</b></div>
          <form onSubmit={submitOrder} className="customer-form"><h3>ข้อมูลสำหรับจัดส่ง</h3><div className="form-grid"><label>ชื่อ-นามสกุล *<input name="name" value={customer.name} onChange={changeCustomer} required placeholder="ชื่อผู้รับ"/></label><label>เบอร์โทรศัพท์ *<input name="phone" value={customer.phone} onChange={changeCustomer} required inputMode="tel" placeholder="08XXXXXXXX"/></label><label className="full">ที่อยู่ *<textarea name="address" value={customer.address} onChange={changeCustomer} required placeholder="บ้านเลขที่ หมู่บ้าน ถนน ซอย" rows="2"/></label><label>อำเภอ/เขต<input name="district" value={customer.district} onChange={changeCustomer} placeholder="อำเภอ/เขต"/></label><label>จังหวัด *<input name="province" value={customer.province} onChange={changeCustomer} required placeholder="จังหวัด"/></label><label>รหัสไปรษณีย์ *<input name="postcode" value={customer.postcode} onChange={changeCustomer} required inputMode="numeric" maxLength="5" placeholder="10110"/></label></div><button className="submit-btn" disabled={loading||!cartItems.length}>{loading?'กำลังบันทึก...':<>ยืนยันคำสั่งซื้อ <span>→</span></>}</button><small className="form-foot">* กรุณาตรวจสอบข้อมูลจัดส่งก่อนยืนยันคำสั่งซื้อ</small></form></div></section>
      </main>
      <footer><div className="brand"><span className="brand-icon"><Leaf size={20}/></span><span>SOAP <b>NATURE</b><small>ธรรมชาติ เพื่อผิวของคุณ</small></span></div><p>© 2026 Soap Nature. สงวนลิขสิทธิ์</p></footer>
    </>:<main className="admin"><div className="admin-head"><div><span className="eyebrow">FULFILLMENT CENTER</span><h1>จัดการคำสั่งซื้อ</h1><p>ตรวจสอบรายการ หยิบสินค้า แพ็กสินค้า และพิมพ์ใบจ่าหน้าพัสดุ</p></div><button className="refresh" onClick={loadOrders}>↻ โหลดข้อมูลล่าสุด</button></div><div className="workflow"><div><ClipboardList/><b>1. รับออเดอร์</b><small>ตรวจสอบข้อมูลลูกค้า</small></div><div><ShoppingBag/><b>2. Picking</b><small>หยิบสินค้าตาม SKU</small></div><div><PackageCheck/><b>3. Packing</b><small>ตรวจสอบและแพ็กสินค้า</small></div><div><Truck/><b>4. Shipping</b><small>พิมพ์ใบจ่าหน้า</small></div></div><div className="admin-toolbar"><div><h2>รายการคำสั่งซื้อ</h2><p>ทั้งหมด {orders.length} รายการ</p></div><div className="search"><Search size={17}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="ค้นหาเลขออเดอร์หรือชื่อลูกค้า"/></div></div>{!API&&<div className="warning">โหมดตัวอย่าง: คำสั่งซื้อจะอยู่ในหน่วยความจำของเบราว์เซอร์นี้เท่านั้น กรุณาตั้งค่า Google Apps Script URL เพื่อใช้งานร่วมกับ Google Sheets จริง</div>}
      <div className="orders">{visibleOrders.length===0?<div className="empty-orders">ยังไม่มีคำสั่งซื้อ หรือไม่พบข้อมูลที่ค้นหา</div>:visibleOrders.map(o=><article className="order-card" key={o.orderId}><div className="order-top"><div><span className="sku">{o.orderId}</span><h3>{o.name}</h3><small>{new Date(o.createdAt).toLocaleString('th-TH')}</small></div><span className={'status '+(o.status==='จัดส่งแล้ว'?'done':o.status==='กำลังแพ็ก'?'packing':'')}>{o.status}</span></div><div className="order-address">{o.phone} · {o.address} {o.district} {o.province} {o.postcode}</div><div className="pick-table"><div className="pick-head"><span>รายการสินค้า / SKU</span><span>จำนวน</span><span>รวม</span></div>{(o.items||[]).map((i,idx)=><div className="pick-row" key={i.sku}><label><input type="checkbox" checked={!!checked[o.orderId+'-'+idx]} onChange={e=>setChecked(old=>({...old,[o.orderId+'-'+idx]:e.target.checked}))}/><span><b>{i.name}</b><small>{i.sku}</small></span></label><b>{i.qty}</b><b>{money(i.price*i.qty)}</b></div>)}</div><div className="order-actions"><strong>ยอดรวม {money(Number(o.total)||0)}</strong><div><select aria-label="สถานะคำสั่งซื้อ" value={o.status} onChange={e=>setStatus(o,e.target.value)}><option>รอหยิบสินค้า</option><option>กำลังหยิบสินค้า</option><option>กำลังแพ็ก</option><option>แพ็กเรียบร้อย</option><option>จัดส่งแล้ว</option></select><button className="label-btn" onClick={()=>openLabel(o)}><Printer size={15}/> พิมพ์ใบจ่าหน้า</button></div></div></article>)}</div></main>}
  </div>
}