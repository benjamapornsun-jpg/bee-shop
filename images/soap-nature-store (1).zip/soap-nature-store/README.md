# Soap Nature – Online Soap Store

เว็บตัวอย่างร้านขายสบู่ มีสินค้า 2 SKUs, ตะกร้าสินค้า, แบบฟอร์มสั่งซื้อ, เชื่อม Google Sheets, หน้าจัดการออเดอร์, Picking/Packing และพิมพ์ใบจ่าหน้าพัสดุ

## 1) รันเว็บไซต์ในเครื่อง
1. ติดตั้ง Node.js เวอร์ชัน LTS
2. แตกไฟล์ ZIP และเปิดโฟลเดอร์ `soap-nature-store`
3. เปิด Terminal แล้วรัน:
   ```bash
   npm install
   npm run dev
   ```
4. เปิด URL ที่ Vite แสดง (ปกติคือ http://localhost:5173)

## 2) ตั้งค่า Google Sheets
1. สร้าง Google Spreadsheet ใหม่
2. ไปที่ Extensions > Apps Script
3. คัดลอกโค้ดจาก `google-apps-script/Code.gs` ไปวางใน `Code.gs`
4. เลือกฟังก์ชัน `setupSheets` แล้วกด Run และอนุญาตสิทธิ์
5. กลับไปที่ Spreadsheet จะมีชีต `Orders`, `OrderItems`, `Products`
6. ใน Apps Script เลือก Deploy > New deployment > Web app
7. Execute as: Me และ Who has access: Anyone (หรือกำหนดการเข้าถึงที่เหมาะสมกับงาน)
8. กด Deploy แล้วคัดลอก Web app URL ที่ลงท้ายด้วย `/exec`

> ข้อควรทราบ: ตัวอย่างนี้เปิด Web App ให้เว็บไซต์เรียกใช้งานได้โดยไม่ต้องล็อกอิน จึงไม่ควรใช้เก็บข้อมูลอ่อนไหวหรือข้อมูลบัตรชำระเงิน หากนำไปใช้จริงควรเพิ่มระบบยืนยันตัวตน/ป้องกันสแปม และทบทวนสิทธิ์การเข้าถึงข้อมูลลูกค้า

## 3) เชื่อมเว็บไซต์กับ Google Sheets
1. คัดลอก `.env.example` เป็นไฟล์ `.env`
2. ใส่ URL ของ Apps Script:
   `VITE_SHEETS_WEB_APP_URL=https://script.google.com/macros/s/DEPLOYMENT_ID/exec`
3. บันทึก แล้วรัน `npm run dev` ใหม่
4. ทดสอบสั่งซื้อ 1 รายการ ตรวจว่าข้อมูลเข้า Orders และ OrderItems

ถ้าไม่ตั้งค่า URL เว็บไซต์จะอยู่ในโหมดตัวอย่าง โดยเก็บข้อมูลชั่วคราวในหน่วยความจำของเบราว์เซอร์เท่านั้น

## 4) โครงสร้าง Google Sheets
- `Orders`: Order ID, วันเวลา, ชื่อลูกค้า, โทรศัพท์, ที่อยู่, จังหวัด, รหัสไปรษณีย์, ยอดรวม, สถานะ
- `OrderItems`: Order ID, SKU, ชื่อสินค้า, ราคา, จำนวน, ยอดรายการ
- `Products`: SKU, ชื่อสินค้า, ราคา, สถานะสินค้า

## 5) อัปโหลด GitHub
1. สร้าง Repository ใหม่ เช่น `soap-nature-store`
2. อัปโหลดไฟล์ทั้งหมดในโฟลเดอร์นี้ (ไม่อัปโหลด `node_modules` และ `.env`)
3. รูปภาพอยู่ใน `public/images/` แยกจาก Source Code
4. ควรใช้ Repository แบบ Private หากมีข้อมูลหรือไฟล์ที่ไม่ต้องการเผยแพร่

## 6) Deploy บน Vercel
1. เข้า https://vercel.com และเลือก Add New > Project
2. Import Git Repository ที่สร้างไว้
3. Framework Preset: Vite
4. Build Command: `npm run build`
5. Output Directory: `dist`
6. เพิ่ม Environment Variable:
   - Name: `VITE_SHEETS_WEB_APP_URL`
   - Value: URL ของ Google Apps Script `/exec`
7. กด Deploy
8. เมื่อ Deploy สำเร็จ Vercel จะให้ URL เช่น `https://ชื่อโปรเจกต์.vercel.app`

หลังแก้ Environment Variable ให้ Redeploy อีกครั้ง

## 7) การทำงาน Picking / Packing / Shipping
- เปิดเมนู `จัดการออเดอร์`
- ตรวจสอบข้อมูลผู้รับและรายการ SKU/จำนวน
- ติ๊ก checkbox เมื่อหยิบสินค้าแต่ละรายการแล้ว
- เปลี่ยนสถานะตามขั้นตอน: รอหยิบสินค้า > กำลังหยิบสินค้า > กำลังแพ็ก > แพ็กเรียบร้อย > จัดส่งแล้ว
- กด `พิมพ์ใบจ่าหน้า` เพื่อเปิดหน้าพิมพ์และพิมพ์ฉลาก

ใบจ่าหน้าในตัวอย่างเป็นฉลากข้อมูลผู้รับ ไม่ใช่ใบปะหน้าที่มีบาร์โค้ดหรือเลข Tracking จากบริษัทขนส่ง ต้องนำข้อมูลไปสร้างรายการจัดส่งในระบบขนส่งเพื่อรับ Tracking Number ก่อนส่งจริง

## 8) รูปภาพสินค้า
ไฟล์ภาพใน `public/images/` เป็นภาพตัวอย่าง SVG placeholder เพื่อให้โปรเจกต์เปิดได้ทันที สามารถแทนที่ด้วยภาพถ่ายสินค้าจริงโดยใช้ชื่อไฟล์เดิม:
- `aloe-soap.jpg`
- `turmeric-soap.jpg`
- `banner.jpg`

หากยังไม่มีภาพ JPG เว็บไซต์จะ fallback ไปที่ `soap-placeholder.svg` สำหรับภาพสินค้า
